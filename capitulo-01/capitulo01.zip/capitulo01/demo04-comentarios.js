// comentário em uma unica linha 

/**
 * Esse código é Hackerzao
 * Author: Erick Wendel
 * Data: 10/01/2020
 */
 // ignorando a linha abaixo
 // const variavelConstante = 1+2+4+4
 const variavelConstante = 1 + 4 // comentando na linha