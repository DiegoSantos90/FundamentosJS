let variavelSemInicializacao
console.log(
    variavelSemInicializacao,
    typeof(variavelSemInicializacao)
)

variavelSemInicializacao = "Hello world!!"
console.log(
    variavelSemInicializacao,
    typeof(variavelSemInicializacao)
)
variavelSemInicializacao = null   
console.log(
    variavelSemInicializacao,
    typeof(variavelSemInicializacao)
)

