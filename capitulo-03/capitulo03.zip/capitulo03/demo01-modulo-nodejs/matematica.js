class Matematica {
    static somar(valor1, valor2) {
        return valor1 + valor2
    }

    static multiplicar(valor1, valor2) {
        return valor1 * valor2
    }
}

module.exports = Matematica