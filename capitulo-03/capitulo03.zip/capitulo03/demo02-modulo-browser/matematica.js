class Matematica {
    static dividir(valor1, valor2) {
        return valor1 / valor2 
    }
    static subtrair(valor1, valor2) {
        return valor1 - valor2
    }
}
